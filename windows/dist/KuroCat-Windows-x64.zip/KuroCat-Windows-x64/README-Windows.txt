KuroCat with Sound & Music Pulse — Windows x64

使用方法：
1. 解压到任意文件夹。
2. 双击 KuroCat.exe 运行（无需安装、无需管理员权限）。
3. 右键桌面右下角托盘里的小猫图标，可以开关按键音效、切换 7 套音效主题、调整音量、开启音乐律动。

注意事项：
- 请保持 KuroCat.exe 与 SoundThemes 文件夹在一起，否则按键音效不可用。
- 需要 Windows 10 / 11。
- 音乐律动分析的是系统默认输出设备播放的声音；如果播放器切换到其他输出设备，律动不会响应。
- 音频只在内存中实时分析，不录音、不保存、不上传。
- 设置保存在注册表 HKCU\Software\KuroCat；完全鼠标穿透时按 Ctrl+Alt+Shift+P 可恢复。

第三方音效许可见 THIRD_PARTY_NOTICES.md。
